app.factory('userFactory',['$http', '$routeParams', function($http, $routeParams){
  var users = [];
  var factory = {};
  var one = [];
  var loggeduser = {}
  factory.add = function(user, callback){
    $http.post('/add', user)
    .then(
      function(result){
        callback(result)
      });
  }
  factory.login = function(user, callback){
    console.log('here2')
    console.log(user.email)
    $http.post('/login', user)
    .then(
      function(result){
        console.log('back')
        if(typeof result.data === 'string'){
          console.log('ERROR')
            callback(result)
        } else {
          console.log('yes!')
          loggeduser = result.data[0]
          console.log(loggeduser);
          console.log('UP')
          callback(result.data[0])
        }
      });
  }
  factory.showloggeduser = function(callback){
    callback(loggeduser)
    console.log(loggeduser)
    console.log('HEREUP')
  }
  factory.logout = function(){
    loggeduser = {}
    console.log(loggeduser)
  }
  return factory

}])
