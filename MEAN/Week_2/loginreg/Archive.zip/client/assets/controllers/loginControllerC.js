app.controller('loginController', ['userFactory', '$scope', '$location',  function(userFactory, $scope, $location){
  $scope.users = [];
  $scope.one = {};
  $scope.loggeduser = {}

  $scope.check = function(){
  console.log($scope.one)
  console.log($scope.users)
  $scope.msg = []
  $scope.message = false;
  if(!$scope.user.email){
    $scope.message = true;
    $scope.msg.push('Your email is required!')
  }
  if(!$scope.user.first_name){
    $scope.message = true;
    $scope.msg.push('Your first name is required!')
  }
  if(!$scope.user.last_name){
    $scope.message = true;
    $scope.msg.push('Your last name is required!')
  }
  if(!$scope.user.password){
    $scope.message = true;
    $scope.msg.push('Your password is required!')
  }
  if($scope.user.password != $scope.user.conpassword){
    $scope.message = true;
    $scope.msg.push('Your password must match')
  }
  else {
    if($scope.message == false){
      userFactory.add($scope.user, function(result){
          $scope.message = true;
          $scope.msg.push('Email already exist');
      })
    }
  }
};
  $scope.login = function(){
    $scope.msg = []
    $scope.message = false;
    if(!$scope.one.email){
      $scope.message = true;
      $scope.msg.push('Your email is required to login!')
    }
    if(!$scope.one.password){
      $scope.message = true;
      $scope.msg.push('Your password is required to login!')
    } else {
      if($scope.message == false){
        userFactory.login($scope.one, function(result){
            console.log('atscope')
            console.log(result)
            if(typeof result.data === 'string'){
              $scope.message = true;
              $scope.msg.push(result.data);
            } else {
              console.log('down')
              $location.url('/success')
              console.log($scope.loggeduser)
            }
        })
      }
      }
    }
    var showloggeduser = function () {
      userFactory.showloggeduser(function(users){
      console.log(users)
      console.log('UPHERE2')
      $scope.loggeduser = users
      })};
      showloggeduser()
      console.log($scope.loggeduser)
      console.log('UPHERE1')
    $scope.logout = function() {
      userFactory.logout()
      $location.url('/')
    }
}])
