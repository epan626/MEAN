var mathlib = require('./mathlib')();
console.log(mathlib.add(12,10));
console.log(mathlib.multiply(2,2));
console.log(mathlib.square(5));
console.log(mathlib.random(1,10));
